$(document).ready(function() {
  $("#home h1").fitText(0.7, { minFontSize: '20px', maxFontSize: '60px' });
  $("#home h2").fitText(1.2, { minFontSize: '20px', maxFontSize: '40px' });
});

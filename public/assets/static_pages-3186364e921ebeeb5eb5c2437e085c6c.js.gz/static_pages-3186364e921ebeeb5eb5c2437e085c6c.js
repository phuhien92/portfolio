$(document).ready(function() {
  #$("h1,h2,h3,span").fitText(1.6, { minFontSize: '30px', maxFontSize: '60px' });
});
